// interns/QuickInternCreate.tsx
import { useCreate, useNotify, useRefresh, useGetList } from "react-admin";
import { SimpleForm, TextInput, SelectInput, required } from "react-admin";
import {
  DialogContent,
  DialogActions,
  Button,
  Alert,
  CircularProgress,
} from "@mui/material";
import { useState } from "react";

const QuickInternCreate = ({
  onSuccess,
  onCancel,
}: {
  onSuccess: () => void;
  onCancel: () => void;
}) => {
  const [create, { isLoading }] = useCreate();
  const notify = useNotify();
  const refresh = useRefresh();
  const [submitted, setSubmitted] = useState(false);

  const { data: managers, isLoading: isLoadingManagers } = useGetList(
    "employees",
    {
      filter: { active: true },
      pagination: { page: 1, perPage: 100 },
      sort: { field: "firstname", order: "ASC" },
    },
  );

  const managerChoices =
    managers?.map((manager: any) => ({
      id: manager.id,
      name: `${manager.firstname} ${manager.lastname}`,
    })) || [];

  const handleSubmit = (data: any) => {
    setSubmitted(true);

    const selectedManager = managers?.find(
      (m: any) => m.id === parseInt(data.managerId),
    );

    // Créer un email par défaut
    const defaultEmail = `${data.first_name.toLowerCase()}.${data.last_name.toLowerCase()}@intern.com`;

    create(
      "interns",
      {
        data: {
          first_name: data.first_name,
          last_name: data.last_name,
          email: defaultEmail,
          department: selectedManager?.department || "Non spécifié",
          managerId: parseInt(data.managerId),
          isRemunerated: false,
          remuneration: null,
        },
      },
      {
        onSuccess: () => {
          notify("Stagiaire créé avec succès !", { type: "success" });
          refresh();
          onSuccess();
        },
        onError: (err) => {
          notify(`Erreur lors de la création : ${err.message}`, {
            type: "error",
          });
          setSubmitted(false);
        },
      },
    );
  };

  return (
    <>
      <DialogContent>
        {isLoadingManagers ? (
          <div style={{ textAlign: "center", padding: "20px" }}>
            <CircularProgress />
            <p>Chargement des managers...</p>
          </div>
        ) : (
          <SimpleForm onSubmit={handleSubmit} toolbar={null}>
            <TextInput
              source="first_name"
              label="Prénom"
              validate={required()}
              fullWidth
              disabled={isLoading}
            />
            <TextInput
              source="last_name"
              label="Nom"
              validate={required()}
              fullWidth
              disabled={isLoading}
            />
            <SelectInput
              source="department"
              label="Department"
              choices={departmentChoices}
              validate={required()}
              fullWidth
            />
            <SelectInput
              source="managerId"
              label="Manager"
              choices={managerChoices}
              validate={required()}
              fullWidth
              disabled={isLoading}
            />
          </SimpleForm>
        )}
      </DialogContent>

      <DialogActions>
        <Button onClick={onCancel} disabled={isLoading}>
          Annuler
        </Button>
        <Button
          onClick={() => {
            const form = document.querySelector("form");
            if (form) {
              const event = new Event("submit", { bubbles: true });
              form.dispatchEvent(event);
            }
          }}
          disabled={isLoading || isLoadingManagers}
          variant="contained"
          color="primary"
        >
          {isLoading ? <CircularProgress size={24} /> : "Créer"}
        </Button>
      </DialogActions>
    </>
  );
};

export default QuickInternCreate;
